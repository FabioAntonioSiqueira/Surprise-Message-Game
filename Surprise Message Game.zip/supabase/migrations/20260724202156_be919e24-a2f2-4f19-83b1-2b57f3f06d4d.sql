
CREATE TABLE public.messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_slug TEXT NOT NULL DEFAULT 'duda',
  text TEXT NOT NULL,
  author_name TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.messages TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

-- Anyone (guests) can submit a message
CREATE POLICY "Anyone can submit messages"
  ON public.messages FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    length(trim(text)) > 0
    AND length(trim(author_name)) > 0
    AND length(text) <= 5000
    AND length(author_name) <= 100
  );

-- Only authenticated users (the birthday person) can read messages
CREATE POLICY "Authenticated users can read messages"
  ON public.messages FOR SELECT
  TO authenticated
  USING (true);

CREATE INDEX messages_event_slug_idx ON public.messages(event_slug);
