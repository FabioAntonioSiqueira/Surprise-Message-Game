import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { EVENT_CONFIG } from "@/lib/event-config";
import type { Message } from "@/lib/game-store";

export const Route = createFileRoute("/_authenticated/mural")({
  head: () => ({
    meta: [
      { title: "Mural — Duda" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: MuralPage,
});

function MuralPage() {
  const { data: messages = [], isLoading } = useQuery({
    queryKey: ["messages", EVENT_CONFIG.slug],
    queryFn: async (): Promise<Message[]> => {
      const { data, error } = await supabase
        .from("messages")
        .select("id, text, author_name, created_at")
        .eq("event_slug", EVENT_CONFIG.slug)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-soft via-background to-primary-soft">
      <div className="max-w-4xl mx-auto px-4 py-10">
        <header className="mb-10 text-center">
          <div className="text-5xl mb-3">💌</div>
          <h1 className="text-4xl font-bold text-primary">Mural de memórias</h1>
          <p className="text-muted-foreground mt-2">
            Todas as mensagens que escreveram para você
          </p>
          <Link
            to="/admin"
            className="inline-block mt-4 text-sm text-primary hover:underline"
          >
            ← Voltar ao painel
          </Link>
        </header>

        {isLoading ? (
          <p className="text-center text-muted-foreground">Carregando…</p>
        ) : messages.length === 0 ? (
          <p className="text-center text-muted-foreground">Nenhuma mensagem ainda.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {messages.map((m, i) => (
              <article
                key={m.id}
                className="bg-card rounded-3xl shadow-lg shadow-primary/10 p-6 animate-fade-up"
                style={{ animationDelay: `${Math.min(i * 40, 400)}ms` }}
              >
                <p className="text-foreground whitespace-pre-wrap leading-relaxed">
                  {m.text}
                </p>
                <div className="mt-4 pt-4 border-t border-border flex items-center justify-between">
                  <span className="text-sm font-semibold text-primary">— {m.author_name}</span>
                  <time className="text-xs text-muted-foreground">
                    {new Date(m.created_at).toLocaleDateString("pt-BR")}
                  </time>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
