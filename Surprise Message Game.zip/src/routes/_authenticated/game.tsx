import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState, useSyncExternalStore } from "react";
import {
  answer,
  currentOptions,
  getGame,
  nextRound,
  resetGame,
  subscribe,
} from "@/lib/game-store";

export const Route = createFileRoute("/_authenticated/game")({
  head: () => ({
    meta: [
      { title: "Jogo — Duda" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: GamePage,
});

function useGame() {
  return useSyncExternalStore(
    subscribe,
    () => getGame(),
    () => null,
  );
}

function GamePage() {
  const navigate = useNavigate();
  const game = useGame();
  const [selected, setSelected] = useState<string | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);

  // Compute options once per round.
  const roundKey = game ? `${game.currentRound}` : "none";
  const options = useMemo(() => currentOptions(), [roundKey, game?.messages.length]);

  useEffect(() => {
    if (!game) navigate({ to: "/admin" });
  }, [game, navigate]);

  useEffect(() => {
    setSelected(null);
    setShowFeedback(false);
  }, [roundKey]);

  if (!game) return null;

  if (game.finished) {
    return <Results />;
  }

  const msg = game.messages[game.order[game.currentRound]];
  const total = game.order.length;
  const round = game.currentRound + 1;
  const isCorrect = selected === msg.author_name;

  function handlePick(opt: string) {
    if (selected) return;
    setSelected(opt);
    answer(opt);
    setTimeout(() => setShowFeedback(true), 100);
  }

  function handleNext() {
    nextRound();
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-soft via-background to-primary-soft">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6 text-sm text-muted-foreground">
          <span>
            Pergunta <b className="text-foreground">{round}</b> de {total}
          </span>
          <span>
            ✅ {game.correct} &nbsp; ❌ {game.wrong}
          </span>
        </div>

        <div className="h-2 bg-muted rounded-full overflow-hidden mb-8">
          <div
            className="h-full bg-primary transition-all duration-500"
            style={{ width: `${(round / total) * 100}%` }}
          />
        </div>

        <div key={roundKey} className="animate-pop-in">
          <div className="bg-card rounded-3xl shadow-xl shadow-primary/10 p-6 sm:p-10 mb-6 relative">
            <div className="absolute -top-3 -left-2 text-6xl text-primary/20 font-serif leading-none select-none">
              &ldquo;
            </div>
            <p className="text-lg sm:text-xl leading-relaxed whitespace-pre-wrap text-foreground relative z-10">
              {msg.text}
            </p>
          </div>

          <p className="text-center text-sm text-muted-foreground mb-4">
            Quem escreveu isso?
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {options.map((opt) => {
              const isThis = selected === opt;
              const isTheAnswer = opt === msg.author_name;
              let cls =
                "rounded-2xl border-2 bg-card px-5 py-4 text-left font-medium transition-all hover:-translate-y-0.5 hover:border-primary";
              if (selected) {
                if (isTheAnswer) cls = cls + " !border-success !bg-success/10 !text-success-foreground";
                else if (isThis) cls = cls + " !border-destructive !bg-destructive/10 animate-shake";
                else cls = cls + " opacity-50";
              } else {
                cls = cls + " border-input";
              }
              return (
                <button
                  key={opt}
                  onClick={() => handlePick(opt)}
                  disabled={!!selected}
                  className={cls}
                >
                  {opt}
                </button>
              );
            })}
          </div>

          {showFeedback && (
            <div className="mt-6 text-center animate-fade-up">
              <div className="text-5xl mb-2">{isCorrect ? "🎉" : "😅"}</div>
              <p className="text-lg font-semibold mb-1">
                {isCorrect ? "Acertou!" : "Não foi dessa vez!"}
              </p>
              <p className="text-sm text-muted-foreground mb-5">
                A mensagem foi escrita por <b className="text-foreground">{msg.author_name}</b>
              </p>
              <button
                onClick={handleNext}
                className="rounded-full bg-primary px-8 py-3 font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-all hover:-translate-y-0.5"
              >
                {round === total ? "Ver resultado" : "Próxima →"}
              </button>
            </div>
          )}
        </div>

        <button
          onClick={() => {
            if (confirm("Sair do jogo? O progresso será perdido.")) {
              resetGame();
              navigate({ to: "/admin" });
            }
          }}
          className="mt-8 mx-auto block text-xs text-muted-foreground hover:text-foreground"
        >
          Sair do jogo
        </button>
      </div>
    </div>
  );
}

function Results() {
  const navigate = useNavigate();
  const game = getGame()!;
  const total = game.answers.length;
  const pct = total > 0 ? Math.round((game.correct / total) * 100) : 0;
  const won = game.correct > game.wrong;

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-soft via-background to-primary-soft relative overflow-hidden">
      {won && <Confetti />}
      <div className="max-w-xl mx-auto px-4 py-16 relative z-10">
        <div className="text-center animate-pop-in">
          <div className="text-7xl mb-4">{won ? "🏆" : "💙"}</div>
          <h1 className="text-4xl font-bold text-primary mb-3">
            {won ? "Você mandou bem!" : "Foi divertido!"}
          </h1>
          <p className="text-muted-foreground mb-10">
            {won
              ? "Você conhece bem quem te ama."
              : "Seus amigos escrevem com muito estilo — você foi enganada com carinho 😄"}
          </p>
        </div>

        <div className="bg-card rounded-3xl shadow-xl shadow-primary/10 p-8 mb-6 animate-fade-up">
          <div className="grid grid-cols-3 gap-4 text-center">
            <Stat label="Total" value={total} />
            <Stat label="Acertos" value={game.correct} accent="success" />
            <Stat label="Erros" value={game.wrong} accent="destructive" />
          </div>
          <div className="mt-8 text-center">
            <div className="text-5xl font-bold text-primary tabular-nums">{pct}%</div>
            <p className="text-sm text-muted-foreground mt-1">de acertos</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => {
              resetGame();
              navigate({ to: "/mural" });
            }}
            className="flex-1 rounded-full bg-primary px-6 py-3.5 font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-all hover:-translate-y-0.5"
          >
            Ver mural de memórias
          </button>
          <button
            onClick={() => {
              resetGame();
              navigate({ to: "/admin" });
            }}
            className="flex-1 rounded-full border-2 border-primary bg-transparent px-6 py-3.5 font-semibold text-primary transition-all hover:bg-primary hover:text-primary-foreground"
          >
            Voltar ao painel
          </button>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: number; accent?: "success" | "destructive" }) {
  const color =
    accent === "success" ? "text-success" : accent === "destructive" ? "text-destructive" : "text-foreground";
  return (
    <div>
      <div className={`text-3xl font-bold tabular-nums ${color}`}>{value}</div>
      <div className="text-xs text-muted-foreground mt-1 uppercase tracking-wide">{label}</div>
    </div>
  );
}

function Confetti() {
  const pieces = Array.from({ length: 60 });
  const colors = ["#2c82b5", "#5aa8d6", "#a9d4ec", "#ffffff", "#ffd166"];
  return (
    <div className="pointer-events-none fixed inset-0 z-0">
      {pieces.map((_, i) => {
        const left = Math.random() * 100;
        const delay = Math.random() * 2;
        const dur = 3 + Math.random() * 3;
        const color = colors[i % colors.length];
        const size = 6 + Math.random() * 8;
        return (
          <span
            key={i}
            style={{
              position: "absolute",
              left: `${left}%`,
              top: "-5vh",
              width: size,
              height: size,
              background: color,
              borderRadius: Math.random() > 0.5 ? "50%" : "2px",
              animation: `confetti-fall ${dur}s linear ${delay}s infinite`,
            }}
          />
        );
      })}
    </div>
  );
}
