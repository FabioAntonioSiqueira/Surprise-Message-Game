import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { EVENT_CONFIG } from "@/lib/event-config";
import { startGame, type Message } from "@/lib/game-store";
import { toast } from "sonner";
import { useState } from "react";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Painel — Duda" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [copied, setCopied] = useState(false);

  const { data: messages = [], isLoading } = useQuery({
    queryKey: ["messages", EVENT_CONFIG.slug],
    queryFn: async (): Promise<Message[]> => {
      const { data, error } = await supabase
        .from("messages")
        .select("id, text, author_name, created_at")
        .eq("event_slug", EVENT_CONFIG.slug)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const uniqueAuthors = new Set(messages.map((m) => m.author_name)).size;
  const canPlay = messages.length >= 2 && uniqueAuthors >= 2;

  const publicUrl = typeof window !== "undefined" ? window.location.origin + "/" : "";

  function handleStart() {
    if (!canPlay) {
      toast.error("Precisa de pelo menos 2 mensagens de autores diferentes.");
      return;
    }
    startGame(messages);
    navigate({ to: "/game" });
  }

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  function copyLink() {
    navigator.clipboard.writeText(publicUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-soft via-background to-primary-soft">
      <div className="max-w-3xl mx-auto px-4 py-10">
        <header className="flex items-center justify-between mb-10">
          <div>
            <h1 className="text-3xl font-bold text-primary">Olá, {EVENT_CONFIG.name} {EVENT_CONFIG.emoji}</h1>
            <p className="text-sm text-muted-foreground">Seu painel do jogo de mensagens</p>
          </div>
          <button
            onClick={handleSignOut}
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            Sair
          </button>
        </header>

        <section className="bg-card rounded-3xl shadow-xl shadow-primary/10 p-6 sm:p-8 mb-6 animate-fade-up">
          <h2 className="text-xl font-semibold mb-4">Mensagens recebidas</h2>
          <div className="flex items-baseline gap-3 mb-6">
            <span className="text-6xl font-bold text-primary tabular-nums">
              {isLoading ? "…" : messages.length}
            </span>
            <span className="text-muted-foreground">
              {messages.length === 1 ? "mensagem" : "mensagens"} de {uniqueAuthors}{" "}
              {uniqueAuthors === 1 ? "pessoa" : "pessoas"}
            </span>
          </div>

          <button
            onClick={handleStart}
            disabled={!canPlay}
            className="w-full rounded-full bg-primary px-6 py-4 font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-all hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0"
          >
            🎮 Começar o jogo
          </button>
          {!canPlay && !isLoading && (
            <p className="text-xs text-muted-foreground mt-3 text-center">
              Espere ao menos 2 mensagens de pessoas diferentes.
            </p>
          )}
        </section>

        <section className="bg-card rounded-3xl shadow-xl shadow-primary/10 p-6 sm:p-8 mb-6 animate-fade-up">
          <h2 className="text-xl font-semibold mb-2">Link para os convidados</h2>
          <p className="text-sm text-muted-foreground mb-4">
            Compartilhe este link (ou faça um QR Code) para que os convidados enviem mensagens.
          </p>
          <div className="flex gap-2">
            <input
              readOnly
              value={publicUrl}
              className="flex-1 rounded-2xl border-2 border-input bg-muted px-4 py-3 text-sm font-mono"
              onFocus={(e) => e.currentTarget.select()}
            />
            <button
              onClick={copyLink}
              className="rounded-2xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-all hover:-translate-y-0.5"
            >
              {copied ? "✓" : "Copiar"}
            </button>
          </div>
          <a
            href={`https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(publicUrl)}`}
            target="_blank"
            rel="noreferrer"
            className="inline-block mt-4 text-sm text-primary hover:underline"
          >
            → Gerar QR Code
          </a>
        </section>

        <Link
          to="/mural"
          className="block text-center text-sm text-primary hover:underline"
        >
          Ver mural de memórias
        </Link>
      </div>
    </div>
  );
}
