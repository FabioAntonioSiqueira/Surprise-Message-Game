import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { EVENT_CONFIG } from "@/lib/event-config";

export const Route = createFileRoute("/")({
  component: Index,
});

const schema = z.object({
  author_name: z.string().trim().min(1, "Diz seu nome!").max(100),
  text: z.string().trim().min(3, "Escreve uma mensagem um pouquinho maior 💌").max(5000),
});

function Index() {
  const [name, setName] = useState("");
  const [text, setText] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse({ author_name: name, text });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Preencha os campos");
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from("messages").insert({
      event_slug: EVENT_CONFIG.slug,
      author_name: parsed.data.author_name,
      text: parsed.data.text,
    });
    setSubmitting(false);
    if (error) {
      toast.error("Não deu pra enviar. Tenta de novo?");
      return;
    }
    setDone(true);
  }

  if (done) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary-soft via-background to-primary-soft flex items-center justify-center px-4 py-10">
        <div className="mx-auto w-full max-w-2xl px-2 sm:px-6">
          <div className="text-center animate-pop-in">
            <div className="text-6xl mb-4 animate-float-slow">💌</div>
            <h1 className="text-3xl sm:text-4xl mb-4 font-bold text-primary">Mensagem enviada!</h1>
            <p className="text-base sm:text-lg text-muted-foreground mb-8">
              Obrigada por participar! Sua mensagem ficará em segredo até o dia do jogo. A {EVENT_CONFIG.name} vai
              adorar 💙
            </p>
            <button
              onClick={() => {
                setName("");
                setText("");
                setDone(false);
              }}
              className="inline-flex items-center justify-center rounded-full border-2 border-primary bg-transparent px-6 py-3 text-sm font-medium text-primary transition-all hover:bg-primary hover:text-primary-foreground"
            >
              Enviar outra mensagem
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-soft via-background to-primary-soft py-8 px-3">
      <div className="mx-auto w-full max-w-2xl px-2 sm:px-6">
        <div className="text-center mb-8 animate-fade-up">
          <h1
            className="text-4xl sm:text-5xl font-bold text-primary mb-3"
            style={{ fontFamily: "'Dancing Script', cursive" }}
          >
            Duda's party
          </h1>
          <p className="text-base sm:text-lg text-muted-foreground leading-relaxed whitespace-pre-line">{EVENT_CONFIG.welcomeSubtitle}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 animate-fade-up" style={{ animationDelay: "0.1s" }}>
          <div>
            <label htmlFor="text" className="block text-sm font-semibold text-foreground mb-2">
              Sua mensagem para a {EVENT_CONFIG.name}
            </label>
            <textarea
              id="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={6}
              placeholder="Uma memória,uma piada interna, uma homenegem... ✨"
              className="w-full rounded-2xl border-2 border-input bg-background/80 backdrop-blur px-4 py-3 text-base text-foreground placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-4 focus:ring-primary/15 resize-y transition-all"
              required
            />
          </div>

          <div>
            <label htmlFor="name" className="block text-sm font-semibold text-foreground mb-2">
              Seu nome (fica escondido até o jogo!)
            </label>
            <input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Como a Duda te conhece"
              className="w-full rounded-2xl border-2 border-input bg-background/80 backdrop-blur px-4 py-3 text-base text-foreground placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-4 focus:ring-primary/15 transition-all"
              maxLength={100}
              required
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full inline-flex items-center justify-center rounded-full bg-primary px-6 py-4 text-base font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-all hover:bg-[oklch(0.52_0.14_240)] hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {submitting ? "Enviando..." : "Enviar mensagem"}
          </button>
        </form>
      </div>
      <p className="text-center text-xs text-muted-foreground mt-6">Feito com carinho para a festa da Duda 💙</p>
    </div>
  );
}
