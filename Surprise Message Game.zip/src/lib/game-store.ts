// Simple in-memory game state shared across admin routes for a single session.


// zustand is not installed; use a tiny hand-rolled store instead.
export type Message = {
  id: string;
  text: string;
  author_name: string;
  created_at: string;
};

export type GameState = {
  messages: Message[];
  authors: string[]; // unique author list
  order: number[]; // shuffled indices into messages
  currentRound: number; // 0-based
  correct: number;
  wrong: number;
  answers: Array<{ messageId: string; correctAuthor: string; guessedAuthor: string; isCorrect: boolean }>;
  finished: boolean;
};

let state: GameState | null = null;
const listeners = new Set<() => void>();

export function getGame(): GameState | null {
  return state;
}
export function subscribe(fn: () => void) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
function emit() {
  listeners.forEach((l) => l());
}

function shuffle<T>(arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function startGame(messages: Message[]) {
  const authors = Array.from(new Set(messages.map((m) => m.author_name)));
  const order = shuffle(messages.map((_, i) => i));
  state = {
    messages,
    authors,
    order,
    currentRound: 0,
    correct: 0,
    wrong: 0,
    answers: [],
    finished: false,
  };
  emit();
}

export function currentOptions(): string[] {
  if (!state) return [];
  const msg = state.messages[state.order[state.currentRound]];
  const correct = msg.author_name;
  const others = state.authors.filter((a) => a !== correct);
  const decoys = shuffle(others).slice(0, 3);
  return shuffle([correct, ...decoys]);
}

export function answer(guessedAuthor: string) {
  if (!state || state.finished) return;
  const msg = state.messages[state.order[state.currentRound]];
  const isCorrect = guessedAuthor === msg.author_name;
  state = {
    ...state,
    answers: [
      ...state.answers,
      { messageId: msg.id, correctAuthor: msg.author_name, guessedAuthor, isCorrect },
    ],
    correct: state.correct + (isCorrect ? 1 : 0),
    wrong: state.wrong + (isCorrect ? 0 : 1),
  };
  emit();
}

export function nextRound() {
  if (!state) return;
  const isLast = state.currentRound + 1 >= state.order.length;
  state = {
    ...state,
    finished: isLast ? true : state.finished,
    currentRound: isLast ? state.currentRound : state.currentRound + 1,
  };
  emit();
}

export function resetGame() {
  state = null;
  emit();
}
