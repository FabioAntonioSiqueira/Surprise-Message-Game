export const EVENT_CONFIG = {
  slug: "duda",
  name: "Duda",
  emoji: "🎂",
  welcomeTitle: "Feliz aniversário, Duda!",
  welcomeSubtitle:
    "Escreva uma mensagem especial para a aniversariante. Durante a festa, ela terá a missão de descobrir quem escreveu cada uma delas.\n\nMas não estrague a surpresa: não conte para ela o que você escreveu!",
} as const;
